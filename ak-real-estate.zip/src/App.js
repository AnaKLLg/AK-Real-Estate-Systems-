
import React, { useState } from 'react';
import './App.css';

export default function App() {
  const [menuOpen, setMenuOpen] = useState(false);

  return (
    <div className="bg-white text-gray-800">
      <h1 className="text-4xl font-bold text-center pt-10">AK Real Estate Systems</h1>
      <p className="text-center text-gray-600 mt-4">Your component was successfully inserted.</p>
    </div>
  );
}
